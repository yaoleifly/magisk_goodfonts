MODDIR=${0%/*}
print_modname() {
  ui_print "酷安@清明蚂蚁🐜"
  ui_print "一加字体模板模块"
  ui_print "正在前往作者酷安主页 "
}
print_modname
function KOOLAPK() {
am start -a android.intent.action.VIEW -d "coolmarket://www.coolapk.com/u/3705147" >/dev/null
}
KOOLAPK
SKIPUNZIP=0